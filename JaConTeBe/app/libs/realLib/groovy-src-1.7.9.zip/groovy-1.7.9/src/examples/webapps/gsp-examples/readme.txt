TODO First, implement http://jira.codehaus.org/browse/GROOVY-839
TODO Second, setup WEB-INF and examples gsp files.